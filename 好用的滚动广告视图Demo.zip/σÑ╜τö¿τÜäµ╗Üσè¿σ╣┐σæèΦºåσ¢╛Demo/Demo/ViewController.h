//
//  ViewController.h
//  Demo
//
//  Created by Ethan on 13-5-15.
//  Copyright (c) 2013年 Ethan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EScrollerView.h"
@interface ViewController : UIViewController<EScrollerViewDelegate>

@end
